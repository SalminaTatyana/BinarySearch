﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearch_Salmina_AS_21
{
    class Program
    {
        static void Main(string[] args)
        {
            Random randomizer = new Random((int)DateTimeOffset.Now.ToUnixTimeMilliseconds());
            float[] secretNumbers = new float[16];

            Console.WriteLine($" Генерируем {secretNumbers.Length} случайных дробных числа...");
            for (int i = 0; i < secretNumbers.Length; ++i)
            {
                secretNumbers[i] = randomizer.Next(1, 10) + (float)randomizer.NextDouble();
            }
            for (int i = 0; i < secretNumbers.Length; ++i)
            {
                for (int j = secretNumbers.Length-1; j >i ; j--)
                {
                    if (secretNumbers[i] > secretNumbers[j])
                    {
                        float k = secretNumbers[i];
                        secretNumbers[i] = secretNumbers[j];
                        secretNumbers[j] = k;
                    }
                }
            }
            Console.WriteLine($"Числа в массиве: ");
            for (int i = 0; i < secretNumbers.Length; ++i)
            {
                Console.Write(secretNumbers[i]+" ");
            }
            Console.WriteLine($" Введите число для поиска: ");
            float searchNumber = Convert.ToSingle(Console.ReadLine()); // Здесь должен быть ввод дробного числа пользователем из консол
            Console.WriteLine(BinarySearchByValue(secretNumbers,searchNumber));
            Console.ReadKey();
        }

        static int BinarySearchByValue(float[] array, float value)
        {
            int left = 0;
            int right = array.Length-1;
            while (left != right)
            {
                int mid = (int)Math.Round((double)((left + right) / 2));
                if (Math.Abs(array[mid]-value)<0.01)
                {
                    return (mid+1);
                }
                if (array[mid] > value)
                {
                    right = mid - 1;
                }
                else
                    left = mid + 1;
            }
            return -1;
        }
    }
}
